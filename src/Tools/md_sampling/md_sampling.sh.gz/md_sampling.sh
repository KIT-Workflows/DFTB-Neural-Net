
# Purpose: 
# To Automate the process of generating the molecular dynamics simulation and get the output file. 

# Comment:
# Still need to manually adjust the dftb input file. 
# Only generates the MD simulation file, still need python module to collect those files. 
echo $1 
echo $2 
cp ./example_molecules/$1.xyz input_geometry.xyz
python xyz_to_gen.py
dftb+ > dftb_output.out
./zip_samples.sh $2

