

import numpy as np
import pandas as pd
import os

import utils.DirNav
from ase.io import write


def add_ref_geom(train_name):
    project_dir = utils.DirNav.get_project_dir()
    samples_dir = os.path.join( project_dir,  'md_capture', 'samples')  # Changed !!

    train_dir = os.path.join(samples_dir, train_name)

    # Load the Training Sets
    md_train_arr_name = os.path.join(train_dir, 'md_train_arr.pkl')
    md_low_rel_e_arr_name = os.path.join( train_dir, 'md_low_rel_e_arr_SCC.txt')
    md_high_rel_e_arr_name = os.path.join(train_dir, 'md_high_rel_e_arr.txt')

    try:
        md_train_arr = pd.read_pickle(md_train_arr_name)

    except:
        try:
            md_samples_arr_name = os.path.join(train_dir, 'md_samplesArr.pkl')
            md_train_arr  = pd.read_pickle(md_samples_arr_name)
        except:
            try:
                md_samples_arr_name = os.path.join(train_dir , 'md_samples_arr.pkl')
                md_train_arr = pd.read_pickle(md_samples_arr_name)
            except:
                raise OSError("Cannot read md_samples_arr, md_calc_rel_e_arr")

    try:
        md_low_rel_e_arr = np.loadtxt(md_low_rel_e_arr_name)
        md_high_rel_e_arr = np.loadtxt(md_high_rel_e_arr_name)
    except:
        raise OSError("Cannot Read md_calc_rel_e_arr")


    # Identify the Index of the global minimum
    if len(md_low_rel_e_arr) != len(md_high_rel_e_arr):
        print("Size of the low energy array: " , len(md_low_rel_e_arr))
        print("Size of the high energy array: ", len(md_high_rel_e_arr))
        raise OSError("md_low_e_arr & md_high_e_arr does not have the same size")

    # Get the Global Energy Minimum structure of the DFT energy
    min_idx   = np.argmin(md_high_rel_e_arr)
    ref_geom  = md_train_arr.iloc[min_idx]

    ref_geom_name = os.path.join(train_dir, 'ref_geom.xyz')
    write(ref_geom_name, ref_geom)



if __name__ == '__main__':
    lib_list = [
        'glycine'                                 ,
         'glycine_opt_b3lyp631G',
         'glycine_190_400K_10000s'                 ,
         'glycine_opt_b3lyp631G_real',
        'glycine_non_opt_350_20000s',
         'glycine_opt_b3lyp631G_real1',
         'glycine_non_opt_b3lyp631G_400K_100000s',
         'rotating_120_180_append',
         'glycine_non_opt_b3lyp631G_400K_20000s',
        'rotating_60_400K_hybrid',
         'glycine_opt'
    ]



    fail_list = []
    success_list = []
    for lib_name in lib_list:
        try:
            #import pdb; pdb.set_trace()
            add_ref_geom(lib_name)
        except:
            fail_list.append(lib_name)
            continue
        success_list.append(lib_name)

    print("Successfully Test the System:", success_list)
    print("Failed Test the System:", fail_list)
