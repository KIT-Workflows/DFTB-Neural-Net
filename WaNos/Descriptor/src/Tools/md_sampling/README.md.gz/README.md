# ReadMe.md #
# DFTB+ Sampling Module #
This Module is designed to generate the molecular dynamics simulation trajectory.

## Up-To-Date Usage ##
`./md_sampling.sh input_file_name export_name`
where input_file_name is the file name for the `.xyz` file of molecule that you want to run MD 
trajectory on. The result will be automatically saved to a newly created folder in ./samples.

Example Usage:
`./md_sampling.sh glycine_190 glycine_190_400K_10000s`


## New Usage ## 
0. First Authorize the shell script to run 
1. Config the DFTB+ input file in 'dftb_in.hsd'
2. Copy the input file (in `xyz` format) to the directory as `input_geometry.xyz`
3. Run the sampling procedure. 
`./md_sampling.sh`

## Old Usage ##
1. First Authorize the shell script to run.
`chmod 755 ./md_sampling.sh` <br/>
`chmod 755 ./clean_samples.sh`<br/>
2. Config the DFTB+ input file `dftb_in.hsd` <br/>
3. Copy the input file (in `xyz` format) to the directory `input_geometry.xyz`  
4. Run the sampling procedure.
`./md_sampling.sh` <br/>
5. (Use Python package to collect the output file.) <br/>
6. Clean up the samples by running <br/>
`./clean_samples.sh`<br/>
