
# Current Status:
# Abandoned because of underperformance when compared with Python File IO. 

# Fundamental Prerequisite for running this file
# 1. Have a defined dftb_in.hsd file, which would usually remain the same file. 
# 2. (For most cases) 
#    Have a defined input_geometry.gen file defined. 



# File Requirement:
# 1. xyz_to_gen.py
# 2. dftb_in.hsd

# Software Requirement:
# 1. Working dftb+ 

clean_samples.sh

python xyz_to_gen.py

for ((i = 0; i <= $1 ; ++i))
do
	# To test whether the for loop works
	echo "Iteration #" "$i"
	if [ $i == 1 ]; 
	then
		# To save the input geometry
		cp input_geometry.gen samples
		echo "Welcome to use the DFTB+ MD Sampling Procedure"
	fi 
	dftb+
	rm input_geometry.gen
	cp geom.out.gen ./samples/$i.out.gen
	cp geom.out.xyz ./samples/$i.xyz
	cp detailed.out ./samples/$i.out
	mv geom.out.gen input_geometry.gen 
done
rm *.out
rm *.gen 
