./uninstallCython.sh
mkdir build
python3 setup.py build_ext --inplace
#mv ./SymmDerivIndCython.cpython-36m-x86_64-linux-gnu.so ./SymmFuncIndCython.cpython-36m-x86_64-linux-gnu.so ..
