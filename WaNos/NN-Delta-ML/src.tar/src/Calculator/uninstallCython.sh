rm -rf build *.so *.c *.html dftb_in.hsd dftb_pin.hsd geo_end.gen geo_end.xyz *.out __pycache__
