# Scripts to Switch The keras Backend to Tensorflow
source deactivate
cp ~/.keras/keras_tf.json ~/.keras/keras.json
source activate tensorflow
