
mkdir samples/$1
mv *.out *.gen *.traj *.txt *.xyz  *.bin  geom.out.xyz  *.gen.xyz  dftb_pin.hsd samples/$1
cp dftb_in.hsd samples/$1
